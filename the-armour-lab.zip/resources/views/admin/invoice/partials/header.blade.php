<style>
    .content{
        overflow: hidden
    }
</style>
<div class="row p-sm-3 p-0">
    <div class="col-md-4 mb-md-0 mb-4">
        <div class="">
            <span class="app-brand-logo demo text-center ">
                <img class="d-inline-block text-center" src="{{ asset('logo.webp') }}">
            </span>
        </div>
    </div>
    <div class="col-md-4" style="text-align: center;">
        <h2 class="mb-1" style=" color: #040404 !important;">THE ARMOUR LAB</h2>
        <p class="mb-1">701 MILLWAY AVENUE, UNIT 6, VAUGHAN, ON L4K 3S7</p>
        <p class="mb-1">T: 416-675-6853</p>
        <p class="mb-1">E: INFO@THEARMOURLAB.COM</p>
        <p class="mb-1">WWW.THEARMOURLAB.COM</p>
    </div>
    <div class="col-md-4" style="text-align: center;">
        <h1 style=" color: #040404 !important;">WORK</h1>
        <h1 style=" color: #040404 !important;">ORDER</h1>
    </div>
</div>
