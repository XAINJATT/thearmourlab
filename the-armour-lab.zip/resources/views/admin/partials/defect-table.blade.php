<table class="table table-bordered border-primary">
    <tr>
        <th>SH</th>
        <td>Swirls/Hologram</td>
    </tr>
    <tr>
        <th>WS</th>
        <td>Water Spots</td>
    </tr>
    <tr>
        <th>OX</th>
        <td>Oxidation</td>
    </tr>
    <tr>
        <th>CF</th>
        <td>Clear Coat Failure</td>
    </tr>
    <tr>
        <th>DS</th>
        <td>Deep Scratch</td>
    </tr>
    <tr>
        <th>BD</th>
        <td>Bird Droppings</td>
    </tr>
    <tr>
        <th>RP</th>
        <td>Rough Paint</td>
    </tr>
    <tr>
        <th>PT</th>
        <td>Paint Transfer</td>
    </tr>
    <tr>
        <th>UD</th>
        <td>Unknown Defect</td>
    </tr>
    <tr>
        <th>PC</th>
        <td>Paint Chip</td>
    </tr>
    <tr>
        <th>DD</th>
        <td>Dings/Dents</td>
    </tr>
    <tr>
        <th>GC</th>
        <td>Glass Chip</td>
    </tr>
    <tr>
        <th>GS</th>
        <td>Glass Scratch</td>
    </tr>
    <tr>
        <th>CR</th>
        <td>Curb Rash</td>
    </tr>
    <tr>
        <th>WD</th>
        <td>Wheel Damage</td>
    </tr>
</table>
