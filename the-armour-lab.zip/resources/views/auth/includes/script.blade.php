<!-- External JavaScripts -->
<script src="js/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="vendor/bootstrap-select/bootstrap-select.min.js"></script>
<script src="js/functions.js"></script>
<script src="js/contact.js"></script>
@yield('scripts')
