<table class="table table-hover">
    <tr>
        <th>Packages</th>
        <th>POLY</th>
        <th>QUARTZ</th>
        <th>QUARTZ +</th>
        <th>KENZO</th>
        <th>INTERIOR</th>
        <th>MAINTENANCE WASH</th>
    </tr>
    <tr>
        <td>Hardness of coating</td>
        <td>8H</td>
        <td>9H</td>
        <td>9H GRAPHENE INFUSED</td>
        <td>10H GRAPHENE INFUSED</td>
        <td>✖</td>
        <td>✖</td>
    </tr>
    <tr>
        <td>PRICE</td>
        <td>$449.99</td>
        <td>$749.99</td>
        <td>$1049.99</td>
        <td>$1249.99</td>
        <td>$449.99</td>
        <td>$249.99</td>
    </tr>
    <tr>
        <td>ESTIMATED TIME</td>
        <td>24 HRS</td>
        <td>24 HRS</td>
        <td>48 HRS</td>
        <td>48 HRS</td>
        <td>3-5 HRS</td>
        <td>8 HRS</td>
    </tr>
    <tr>
        <td>TWO BUCKET WASH</td>
        <td> ✔</td>
        <td> ✔</td>
        <td> ✔</td>
        <td>✔</td>
        <td>✖</td>
        <td> ✔</td>
    </tr>
    <tr>
        <td>CLAY BAR TREATMENT</td>
        <td> ✔</td>
        <td> ✔</td>
        <td> ✔</td>
        <td>✖</td>
        <td>✖</td>
        <td> ✔</td>
    </tr>
    <tr>
        <td>IRON AND DECON REMOVAL</td>
        <td> ✔</td>
        <td> ✔</td>
        <td> ✔</td>
        <td>✖</td>
        <td> ✔</td>
        <td> ✔</td>
    </tr>
    <tr>
        <td>ONE STAGE SPEED POLISH</td>
        <td>✖</td>
        <td> ✔</td>
        <td> ✔</td>
        <td>✖</td>
        <td>✖</td>
        <td> ✔</td>
    </tr>
    <tr>
        <td>Paint Correction (PER STAGE)</td>
        <td>
            $599.99
        </td>
        <td>
            $599.99
        </td>
        <td>
            $599.99
        </td>
        <td>$599.99</td>
        <td>✖</td>
        <td>✖</td>
    </tr>
    <tr>
        <td>Window coating</td>
        <td>✖</td>
        <td> ✔</td>
        <td> ✔</td>
        <td> ✔</td>
        <td> ✔</td>
        <td> ✔</td>
    </tr>
    <tr>
        <td>Wheel coating</td>
        <td>✖</td>
        <td> ✔</td>
        <td> ✔</td>
        <td> ✔</td>
        <td>✖</td>
        <td>✖</td>
    </tr>
    <tr>
        <td>Full body coating</td>
        <td> ✔</td>
        <td> ✔</td>
        <td> ✔</td>
        <td> ✔</td>
        <td>✖</td>
        <td>✖</td>
    </tr>
    <tr>
        <td>Premier coating</td>
        <td>✖</td>
        <td>✖</td>
        <td>✖</td>
        <td>✖</td>
        <td>✖</td>
        <td>✔</td>
    </tr>
    <tr>
        <td>Trim / Exhaust / Misc coating</td>
        <td>✖</td>
        <td> ✔</td>
        <td> ✔</td>
        <td> ✔</td>
        <td>✖</td>
        <td>✖</td>
    </tr>
    <tr>
        <td>Wheels off package</td>
        <td>✖</td>
        <!-- <td>
            $199.99
        </td> -->
        <td>
            $249.99
        </td>
        <td>
            $249.99
        </td>
        <td>
            $249.99
        </td>
        <td>✖</td>
        <td>✖</td>
    </tr>
</table>
