<table class="table table-hover packages">
    <tr class="package-list">
        <th data-val="val1">Packages</th>
        <th data-val="val2">POLY</th>
        <th data-val="val3">QUARTZ</th>
        <th data-val="val4">QUARTZ +</th>
        <th data-val="val5">KENZO</th>
        <th data-val="val6">INTERIOR</th>
        <th data-val="val7">MAINTENANCE WASH</th>
    </tr>
    <tr class="package-list">
        <td>Hardness of coating</td>
        <td>8H</td>
        <td>9H</td>
        <td>9H GRAPHENE INFUSED</td>
        <td>10H GRAPHENE INFUSED</td>
        <td>✖</td>
        <td>✖</td>
    </tr>

    <tr class="package-list">
        <td>PRICE</td>
        <td id="price1" class="price" data-val="val1">$449.99</td>
        <td id="price2" class="price" data-val="val2">$749.99</td>
        <td id="price3" class="price" data-val="val3">$1049.99</td>
        <td id="price4" class="price" data-val="val4">$1249.99</td>
        <td id="price5" class="price" data-val="val5">$449.99</td>
        <td id="price6" class="price" data-val="val6">$249.99</td>
    </tr>
    <tr class="package-list">
        <td>ESTIMATED TIME</td>
        <td>24 HRS</td>
        <td>24 HRS</td>
        <td>48 HRS</td>
        <td>48 HRS</td>
        <td>3-5 HRS</td>
        <td>8 HRS</td>
    </tr>

    <tr class="package-list">
        <td>Warranty</td>
        <td> 1 Year<br /></td>
        <td> 2 Years<br /></td>
        <td> 4 Years<br /></td>
        <td> 5 Years<br /></td>
        <td> ✖<br /></td>
        <td> ✖<br /></td>
    </tr>

    <tr class="package-list">
        <td>TWO BUCKET WASH</td>
        <td> ✔</td>
        <td> ✔</td>
        <td> ✔</td>
        <td>✔</td>
        <td>✖</td>
        <td> ✔</td>
    </tr>
    <tr class="package-list">
        <td>CLAY BAR TREATMENT</td>
        <td> ✔</td>
        <td> ✔</td>
        <td> ✔</td>
        <td>✔</td>
        <td>✖</td>
        <td> ✔</td>
    </tr>
    <tr class="package-list">
        <td>IRON AND DECON REMOVAL</td>
        <td> ✔</td>
        <td> ✔</td>
        <td> ✔</td>
        <td>✔</td>
        <td> ✖</td>
        <td> ✔</td>
    </tr>
    <tr class="package-list">
        <td>ONE STAGE SPEED POLISH</td>
        <td>✖</td>
        <td> ✔</td>
        <td> ✔</td>
        <td>✔</td>
        <td>✖</td>
        <td> ✖</td>
    </tr>
    <tr class="package-list">
        <td>Paint Correction (PER STAGE)</td>
        <td>
            $599.99
        </td>
        <td>
            $599.99
        </td>
        <td>
            $599.99
        </td>
        <td>$599.99</td>
        <td>✖</td>
        <td>✖</td>
    </tr>
    <tr class="package-list">
        <td>Window coating</td>
        <td>✖</td>
        <td> ✔</td>
        <td> ✔</td>
        <td> ✔</td>
        <td> ✔</td>
        <td> ✔</td>
    </tr>
    <tr class="package-list">
        <td>Wheel coating</td>
        <td>✖</td>
        <td> ✔</td>
        <td> ✔</td>
        <td> ✔</td>
        <td>✖</td>
        <td>✖</td>
    </tr>
    <tr class="package-list">
        <td>Full body coating</td>
        <td> ✔</td>
        <td> ✔</td>
        <td> ✔</td>
        <td> ✔</td>
        <td>✖</td>
        <td>✖</td>
    </tr>
    <tr class="package-list">
        <td>Premier coating</td>
        <td>✖</td>
        <td>✖</td>
        <td>✖</td>
        <td>✖</td>
        <td>✖</td>
        <td>✔</td>
    </tr>
    <tr class="package-list">
        <td>Trim / Exhaust / Misc coating</td>
        <td>✖</td>
        <td> ✔</td>
        <td> ✔</td>
        <td> ✔</td>
        <td>✖</td>
        <td>✖</td>
    </tr>
    <tr class="package-list">
        <td>Wheels off package</td>
        <td>✖</td>
        <!-- <td>
            $199.99
        </td> -->
        <td>
            $249.99
        </td>
        <td>
            $249.99
        </td>
        <td>
            $249.99
        </td>
        <td>✖</td>
        <td>✖</td>
    </tr>
</table>
