<table class="table table-hover packages">
    <tr class="package-list">
        <th>Packages</th>
        <th>POLY</th>
        <th>QUARTZ</th>
        <th>QUARTZ +</th>
        <th>KENZO</th>
        <th>INTERIOR</th>
        <th>MAINTENANCE WASH</th>
    </tr>
    <tr class="package-list">
        <td>Hardness of coating</td>
        <td>8H</td>
        <td>9H</td>
        <td>9H GRAPHENE INFUSED</td>
        <td>10H GRAPHENE INFUSED</td>
        <td>✖</td>
        <td>✖</td>
    </tr>
    <tr class="package-list">
        <td>PRICE</td>
        <td>$399.99</td>
        <td>$599.99</td>
        <td>$899.99 </td>
        <td>$1099.99</td>
        <td>$399.99</td>
        <td>$199.99</td>
    </tr>
    <tr class="package-list">
        <td>ESTIMATED TIME</td>
        <td>24 HRS</td>
        <td>24 HRS</td>
        <td>48 HRS</td>
        <td>48 HRS</td>
        <td>2-4 HRS</td>
        <td>8 HRS</td>
    </tr>
    <tr class="package-list">
        <td>TWO BUCKET WASH</td>
        <td>✔</td>
        <td>✔</td>
        <td>✔</td>
        <td>
            ✔
        </td>
        <td>✖</td>
        <td>✔</td>
    </tr>
    <tr class="package-list">
        <td>CLAY BAR TREATMENT</td>
        <td>✔</td>
        <td>✔</td>
        <td>✔</td>
        <td>✔</td>
        <!-- <td>✖</td> -->
        <td>✖</td>
        <td>✔</td>
    </tr>
    <tr class="package-list">
        <td>IRON AND DECON REMOVAL</td>
        <td>✔</td>
        <td>✔</td>
        <td>✔</td>
        <td>✔</td>
        <!-- <td>✖</td> -->
        <td>✖</td>
        <td>✔</td>
    </tr>
    <tr class="package-list">
        <td>ONE STAGE SPEED POLISH</td>
        <td>✖</td>
        <td>✔</td>
        <td>✔</td>
        <td>✔</td>
        <!-- <td>✖</td> -->
        <td>✖</td>
        <td>✖</td>
    </tr>
    <tr class="package-list">
        <td>Paint Correction (PER STAGE)</td>
        <td>
            $499.99
        </td>
        <td>
            $499.99
        </td>
        <td>
            $499.99
        </td>
        <td>$499.99</td>
        <td>✖</td>
        <td>✖</td>
    </tr>
    <tr class="package-list">
        <td>Window coating</td>
        <td>✖</td>
        <td>✔</td>
        <td>✔</td>
        <td>✔</td>
        <td>✖</td>
        <td>✔</td>
    </tr>
    <tr class="package-list">
        <td>Wheel coating</td>
        <td>✖</td>
        <td>✔</td>
        <td>✔</td>
        <td>✔</td>
        <td>✖</td>
        <td>✖</td>
    </tr>
    <tr class="package-list">
        <td>Full body coating</td>
        <td>✔</td>
        <td>✔</td>
        <td>✔</td>
        <td>✔</td>
        <td>✖</td>
        <td>✖</td>
    </tr>
    <tr class="package-list">
        <td>Premier coating</td>
        <td>✖</td>
        <td>✖</td>
        <td>✖</td>
        <td>✖</td>
        <td>✖</td>
        <td>✔</td>
    </tr>
    <tr class="package-list">
        <td>Trim / Exhaust / Misc coating</td>
        <td>✖</td>
        <!-- <td>✔</td> -->
        <td>✔</td>
        <td>✔</td>
        <td>✔</td>
        <td>✖</td>
        <td>✖</td>
    </tr>
    <tr class="package-list">
        <td>Wheels off package</td>
        <td>✖</td>
        <!-- <td>
            $199.99
        </td> -->
        <td>
            $199.99
        </td>
        <td>
            $199.99
        </td>
        <td>
            $199.99
        </td>
        <td>✖</td>
        <td>✖</td>
    </tr>
</table>
